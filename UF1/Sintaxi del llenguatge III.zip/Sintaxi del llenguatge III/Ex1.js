var d = new Date();
var n = d.toLocaleDateString();
console.log(n);
document.getElementById("demo").innerHTML=n;
