var x=Math.PI //3.141592...

//x.trunc() //error!

console.log(Math.trunc(x)) //3
console.log(Math.round(x)) //3
console.log(Math.ceil(x)) //4
console.log(Math.floor(x)) //3

var x=3.754354

console.log(Math.trunc(x)) //3
console.log(Math.round(x)) //4
console.log(Math.ceil(x)) //4
console.log(Math.floor(x)) //3
